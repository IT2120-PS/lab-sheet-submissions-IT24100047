setwd("C:\\Users\\IT24100047\\Desktop\\IT24100047")
#Q1
branch_data <- read.table("Exercise.txt" , header = TRUE , sep = ",")

#Q2
fix(branch_data)
str(branch_data)
attach(branch_data)

#Q3
#Obtin boxplot for Sales_x1
boxplot(branch_data$Sales_X1,main = "box plot for sales", outline = TRUE, outpch =8 , horizontal = TRUE)

#Q4
##five-number summary 
summary(Advertising_X2)

#IQR
IQR(Advertising_X2)


get.outliers <- function(z) {
  # Calculate the first and third quartiles
  q1 <- quantile(z)[2]
  q3 <- quantile(z)[4]
  
  # Calculate IQR
  iqr <- q3 - q1
  
  # Calculate the upper and lower bounds
  Ub <- q3 + 1.5 * iqr
  lb <- q1 - 1.5 * iqr  # Note: Lower bound should subtract 1.5 * IQR
  
  # Print bounds
  print(paste("Upper Bound = ", Ub))
  print(paste("Lower Bound = ", lb))
  
  # Identify and print outliers
  outliers <- z[z < lb | z > Ub]
  print(paste("Outliers: ", paste(sort(outliers), collapse = ", ")))
  
  # Return outliers as well (optional, for further use)
  return(outliers)
}


